-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: localhost    Database: ssmx393r
-- ------------------------------------------------------
-- Server version	5.7.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(100) NOT NULL COMMENT '配置参数名称',
  `value` varchar(100) DEFAULT NULL COMMENT '配置参数值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='配置文件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'picture1','http://localhost:8080/ssmx393r/upload/picture1.jpg'),(2,'picture2','http://localhost:8080/ssmx393r/upload/picture2.jpg'),(3,'picture3','http://localhost:8080/ssmx393r/upload/picture3.jpg'),(6,'homepage',NULL);
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jiaoshi`
--

DROP TABLE IF EXISTS `jiaoshi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jiaoshi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `jiaoshigonghao` varchar(200) NOT NULL COMMENT '教师工号',
  `mima` varchar(200) NOT NULL COMMENT '密码',
  `jiaoshixingming` varchar(200) NOT NULL COMMENT '教师姓名',
  `bumen` varchar(200) DEFAULT NULL COMMENT '部门',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `shouji` varchar(200) DEFAULT NULL COMMENT '手机',
  `youxiang` varchar(200) DEFAULT NULL COMMENT '邮箱',
  `shenfenzheng` varchar(200) DEFAULT NULL COMMENT '身份证',
  `zhaopian` varchar(200) DEFAULT NULL COMMENT '照片',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jiaoshigonghao` (`jiaoshigonghao`)
) ENGINE=InnoDB AUTO_INCREMENT=1615276185617 DEFAULT CHARSET=utf8 COMMENT='教师';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jiaoshi`
--

LOCK TABLES `jiaoshi` WRITE;
/*!40000 ALTER TABLE `jiaoshi` DISABLE KEYS */;
INSERT INTO `jiaoshi` VALUES (21,'2021-03-09 07:40:51','教师1','123456','教师姓名1','部门1','男','13823888881','773890001@qq.com','440300199101010001','http://localhost:8080/ssmx393r/upload/jiaoshi_zhaopian1.jpg'),(22,'2021-03-09 07:40:51','教师2','123456','教师姓名2','部门2','男','13823888882','773890002@qq.com','440300199202020002','http://localhost:8080/ssmx393r/upload/jiaoshi_zhaopian2.jpg'),(23,'2021-03-09 07:40:51','教师3','123456','教师姓名3','部门3','男','13823888883','773890003@qq.com','440300199303030003','http://localhost:8080/ssmx393r/upload/jiaoshi_zhaopian3.jpg'),(24,'2021-03-09 07:40:51','教师4','123456','教师姓名4','部门4','男','13823888884','773890004@qq.com','440300199404040004','http://localhost:8080/ssmx393r/upload/jiaoshi_zhaopian4.jpg'),(25,'2021-03-09 07:40:51','教师5','123456','教师姓名5','部门5','男','13823888885','773890005@qq.com','440300199505050005','http://localhost:8080/ssmx393r/upload/jiaoshi_zhaopian5.jpg'),(26,'2021-03-09 07:40:51','教师6','123456','教师姓名6','部门6','男','13823888886','773890006@qq.com','440300199606060006','http://localhost:8080/ssmx393r/upload/jiaoshi_zhaopian6.jpg'),(1615276185616,'2021-03-09 07:49:45','4444','4444','电饭锅','化学',NULL,'14444444444','15@qq.com','441421199001125846',NULL);
/*!40000 ALTER TABLE `jiaoshi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shixunbaogao`
--

DROP TABLE IF EXISTS `shixunbaogao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shixunbaogao` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `xiangmubianhao` varchar(200) DEFAULT NULL COMMENT '项目编号',
  `xiangmumingcheng` varchar(200) DEFAULT NULL COMMENT '项目名称',
  `wenjian` varchar(200) DEFAULT NULL COMMENT '文件',
  `xunliantaidu` varchar(200) DEFAULT NULL COMMENT '训练态度',
  `manyichengdu` varchar(200) DEFAULT NULL COMMENT '满意程度',
  `zhanghao` varchar(200) DEFAULT NULL COMMENT '账号',
  `xingming` varchar(200) DEFAULT NULL COMMENT '姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COMMENT='实训报告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shixunbaogao`
--

LOCK TABLES `shixunbaogao` WRITE;
/*!40000 ALTER TABLE `shixunbaogao` DISABLE KEYS */;
INSERT INTO `shixunbaogao` VALUES (41,'2021-03-09 07:40:51','项目编号1','项目名称1','','好','满意','账号1','姓名1'),(42,'2021-03-09 07:40:51','项目编号2','项目名称2','','好','满意','账号2','姓名2'),(43,'2021-03-09 07:40:51','项目编号3','项目名称3','','好','满意','账号3','姓名3'),(44,'2021-03-09 07:40:51','项目编号4','项目名称4','','好','满意','账号4','姓名4'),(45,'2021-03-09 07:40:51','项目编号5','项目名称5','','好','满意','账号5','姓名5'),(46,'2021-03-09 07:40:51','项目编号6','项目名称6','','好','满意','账号6','姓名6');
/*!40000 ALTER TABLE `shixunbaogao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shixunpinggu`
--

DROP TABLE IF EXISTS `shixunpinggu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shixunpinggu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `xiangmubianhao` varchar(200) DEFAULT NULL COMMENT '项目编号',
  `xiangmumingcheng` varchar(200) DEFAULT NULL COMMENT '项目名称',
  `zhanghao` varchar(200) DEFAULT NULL COMMENT '账号',
  `xingming` varchar(200) DEFAULT NULL COMMENT '姓名',
  `pingyu` longtext COMMENT '评语',
  `shifoutongguo` varchar(200) DEFAULT NULL COMMENT '是否通过',
  `dengjishijian` date DEFAULT NULL COMMENT '登记时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COMMENT='实训评估';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shixunpinggu`
--

LOCK TABLES `shixunpinggu` WRITE;
/*!40000 ALTER TABLE `shixunpinggu` DISABLE KEYS */;
INSERT INTO `shixunpinggu` VALUES (51,'2021-03-09 07:40:51','项目编号1','项目名称1','账号1','姓名1','评语1','通过','2021-03-09'),(52,'2021-03-09 07:40:51','项目编号2','项目名称2','账号2','姓名2','评语2','通过','2021-03-09'),(53,'2021-03-09 07:40:51','项目编号3','项目名称3','账号3','姓名3','评语3','通过','2021-03-09'),(54,'2021-03-09 07:40:51','项目编号4','项目名称4','账号4','姓名4','评语4','通过','2021-03-09'),(55,'2021-03-09 07:40:51','项目编号5','项目名称5','账号5','姓名5','评语5','通过','2021-03-09'),(56,'2021-03-09 07:40:51','项目编号6','项目名称6','账号6','姓名6','评语6','通过','2021-03-09');
/*!40000 ALTER TABLE `shixunpinggu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shixunxiangmu`
--

DROP TABLE IF EXISTS `shixunxiangmu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shixunxiangmu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `xiangmubianhao` varchar(200) DEFAULT NULL COMMENT '项目编号',
  `xiangmumingcheng` varchar(200) DEFAULT NULL COMMENT '项目名称',
  `xiangmuneirong` longtext COMMENT '项目内容',
  `tupian` varchar(200) DEFAULT NULL COMMENT '图片',
  `kaishishijian` date DEFAULT NULL COMMENT '开始时间',
  `xunliantianshu` varchar(200) DEFAULT NULL COMMENT '训练天数',
  `beizhu` longtext COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `xiangmubianhao` (`xiangmubianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COMMENT='实训项目';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shixunxiangmu`
--

LOCK TABLES `shixunxiangmu` WRITE;
/*!40000 ALTER TABLE `shixunxiangmu` DISABLE KEYS */;
INSERT INTO `shixunxiangmu` VALUES (31,'2021-03-09 07:40:51','项目编号1','项目名称1','项目内容1','http://localhost:8080/ssmx393r/upload/shixunxiangmu_tupian1.jpg','2021-03-09','训练天数1','备注1'),(32,'2021-03-09 07:40:51','项目编号2','项目名称2','项目内容2','http://localhost:8080/ssmx393r/upload/shixunxiangmu_tupian2.jpg','2021-03-09','训练天数2','备注2'),(33,'2021-03-09 07:40:51','项目编号3','项目名称3','项目内容3','http://localhost:8080/ssmx393r/upload/shixunxiangmu_tupian3.jpg','2021-03-09','训练天数3','备注3'),(34,'2021-03-09 07:40:51','项目编号4','项目名称4','项目内容4','http://localhost:8080/ssmx393r/upload/shixunxiangmu_tupian4.jpg','2021-03-09','训练天数4','备注4'),(35,'2021-03-09 07:40:51','项目编号5','项目名称5','项目内容5','http://localhost:8080/ssmx393r/upload/shixunxiangmu_tupian5.jpg','2021-03-09','训练天数5','备注5'),(36,'2021-03-09 07:40:51','项目编号6','项目名称6','项目内容6','http://localhost:8080/ssmx393r/upload/shixunxiangmu_tupian6.jpg','2021-03-09','训练天数6','备注6');
/*!40000 ALTER TABLE `shixunxiangmu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `userid` bigint(20) NOT NULL COMMENT '用户id',
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `tablename` varchar(100) DEFAULT NULL COMMENT '表名',
  `role` varchar(100) DEFAULT NULL COMMENT '角色',
  `token` varchar(200) NOT NULL COMMENT '密码',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  `expiratedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '过期时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='token表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token`
--

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;
INSERT INTO `token` VALUES (1,1,'abo','users','管理员','r4symjj25b4614aanld29bxhrdu78cck','2021-03-09 07:46:57','2021-03-09 08:50:09'),(2,1615276043051,'1111','xuesheng','学生','jjxvzjle553c2fh3qu97lcp30a753hw6','2021-03-09 07:47:32','2021-03-09 08:47:33'),(3,1615276185616,'4444','jiaoshi','教师','nzhy42vrwim6cn2a150tn76y938f0bfg','2021-03-09 07:49:56','2021-03-09 08:49:57'),(4,1615276228806,'11111','xuesheng','学生','g2fgdj3ahqvkmre7g80r2iutrdcee7h1','2021-03-09 07:50:45','2021-03-09 08:50:46');
/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `role` varchar(100) DEFAULT '管理员' COMMENT '角色',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'abo','abo','管理员','2021-03-09 07:40:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xuesheng`
--

DROP TABLE IF EXISTS `xuesheng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xuesheng` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `zhanghao` varchar(200) NOT NULL COMMENT '账号',
  `mima` varchar(200) NOT NULL COMMENT '密码',
  `xingming` varchar(200) NOT NULL COMMENT '姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `shouji` varchar(200) DEFAULT NULL COMMENT '手机',
  `xuexizhuangtai` varchar(200) DEFAULT NULL COMMENT '学习状态',
  `youxiang` varchar(200) DEFAULT NULL COMMENT '邮箱',
  `shenfenzheng` varchar(200) DEFAULT NULL COMMENT '身份证',
  `zhaopian` varchar(200) DEFAULT NULL COMMENT '照片',
  `dizhi` varchar(200) DEFAULT NULL COMMENT '地址',
  PRIMARY KEY (`id`),
  UNIQUE KEY `zhanghao` (`zhanghao`)
) ENGINE=InnoDB AUTO_INCREMENT=1615276228807 DEFAULT CHARSET=utf8 COMMENT='学生';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xuesheng`
--

LOCK TABLES `xuesheng` WRITE;
/*!40000 ALTER TABLE `xuesheng` DISABLE KEYS */;
INSERT INTO `xuesheng` VALUES (11,'2021-03-09 07:40:51','学生1','123456','姓名1','男','13823888881','未选择','773890001@qq.com','440300199101010001','http://localhost:8080/ssmx393r/upload/xuesheng_zhaopian1.jpg','地址1'),(12,'2021-03-09 07:40:51','学生2','123456','姓名2','男','13823888882','未选择','773890002@qq.com','440300199202020002','http://localhost:8080/ssmx393r/upload/xuesheng_zhaopian2.jpg','地址2'),(13,'2021-03-09 07:40:51','学生3','123456','姓名3','男','13823888883','未选择','773890003@qq.com','440300199303030003','http://localhost:8080/ssmx393r/upload/xuesheng_zhaopian3.jpg','地址3'),(14,'2021-03-09 07:40:51','学生4','123456','姓名4','男','13823888884','未选择','773890004@qq.com','440300199404040004','http://localhost:8080/ssmx393r/upload/xuesheng_zhaopian4.jpg','地址4'),(15,'2021-03-09 07:40:51','学生5','123456','姓名5','男','13823888885','未选择','773890005@qq.com','440300199505050005','http://localhost:8080/ssmx393r/upload/xuesheng_zhaopian5.jpg','地址5'),(16,'2021-03-09 07:40:51','学生6','123456','姓名6','男','13823888886','未选择','773890006@qq.com','440300199606060006','http://localhost:8080/ssmx393r/upload/xuesheng_zhaopian6.jpg','地址6'),(1615276043051,'2021-03-09 07:47:23','1111','1111','的说法是否',NULL,'11111111111',NULL,'11@qq.com','441421199001125846',NULL,'付士大夫士大夫士大夫士大夫'),(1615276228806,'2021-03-09 07:50:28','11111','11111','递四方速递',NULL,'11111111111',NULL,'85@qq.com','441421199001125846',NULL,'鬼地方个梵蒂冈');
/*!40000 ALTER TABLE `xuesheng` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xueshengpingfen`
--

DROP TABLE IF EXISTS `xueshengpingfen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xueshengpingfen` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `zhanghao` varchar(200) DEFAULT NULL COMMENT '账号',
  `xingming` varchar(200) DEFAULT NULL COMMENT '姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `shixuntaidu` varchar(200) DEFAULT NULL COMMENT '实训态度',
  `shixunchengji` varchar(200) DEFAULT NULL COMMENT '实训成绩',
  `zongdefen` varchar(200) DEFAULT NULL COMMENT '总得分',
  `dengjishijian` date DEFAULT NULL COMMENT '登记时间',
  `jiaoshigonghao` varchar(200) DEFAULT NULL COMMENT '教师工号',
  `jiaoshixingming` varchar(200) DEFAULT NULL COMMENT '教师姓名',
  `sfsh` varchar(200) DEFAULT '否' COMMENT '是否审核',
  `shhf` longtext COMMENT '审核回复',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COMMENT='学生评分';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xueshengpingfen`
--

LOCK TABLES `xueshengpingfen` WRITE;
/*!40000 ALTER TABLE `xueshengpingfen` DISABLE KEYS */;
INSERT INTO `xueshengpingfen` VALUES (61,'2021-03-09 07:40:51','账号1','姓名1','性别1','30','30','总得分1','2021-03-09','教师工号1','教师姓名1','是',''),(62,'2021-03-09 07:40:51','账号2','姓名2','性别2','30','30','总得分2','2021-03-09','教师工号2','教师姓名2','是',''),(63,'2021-03-09 07:40:51','账号3','姓名3','性别3','30','30','总得分3','2021-03-09','教师工号3','教师姓名3','是',''),(64,'2021-03-09 07:40:51','账号4','姓名4','性别4','30','30','总得分4','2021-03-09','教师工号4','教师姓名4','是',''),(65,'2021-03-09 07:40:51','账号5','姓名5','性别5','30','30','总得分5','2021-03-09','教师工号5','教师姓名5','是',''),(66,'2021-03-09 07:40:51','账号6','姓名6','性别6','30','30','总得分6','2021-03-09','教师工号6','教师姓名6','是','');
/*!40000 ALTER TABLE `xueshengpingfen` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-09 20:48:09
