const base = {
    get() {
                return {
            url : "http://localhost:8080/ssmx393r/",
            name: "ssmx393r",
            // 退出到首页链接
            indexUrl: 'http://localhost:8080/ssmx393r/front/index.html'
        };
            },
    getProjectName(){
        return {
            projectName: "高校实习实训管理系统"
        } 
    }
}
export default base
